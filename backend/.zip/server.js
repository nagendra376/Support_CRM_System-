const express = require("express");
const cors = require("cors");

const ticketRoutes = require("./routes/ticketRoutes");

const app = express();

// basic configuration
app.use(express.json({ limit: "16kb" })); //read from client
app.use(express.urlencoded({ extended: true, limit: "16kb" }));
app.use(express.static("public"));

//cors configuration
app.use(cors());

app.use("/api/tickets", ticketRoutes);

module.exports = app;
